import { WebhookModel } from "../../models/Webhook";
import User from "../../models/User";
import { FlowBuilderModel } from "../../models/FlowBuilder";
import AttachToolsEnabledToFlow from "./AttachToolsEnabledToFlow";

interface Request {
  companyId: number;
  idFlow: number
}

interface Response {
  flow: FlowBuilderModel
}

const GetFlowBuilderService = async ({
  companyId,
  idFlow
}: Request): Promise<Response> => {
  
    try {
    
        // Realiza a consulta com paginação usando findAndCountAll
        const { count, rows } = await FlowBuilderModel.findAndCountAll({
          where: {
            company_id: companyId,
            id: idFlow
          }
        });
        let flow = rows[0]

        if (flow) {
          await AttachToolsEnabledToFlow(flow, companyId);
        }

        return {
            flow: flow
        }
      } catch (error) {
        console.error('Erro ao consultar usuários:', error);
      }
};

export default GetFlowBuilderService;
